import { SESClient, SendEmailCommand } from "@aws-sdk/client-ses";
import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient, PutCommand } from "@aws-sdk/lib-dynamodb";

const ses = new SESClient({ region: "ca-central-1" });
const dynamo = DynamoDBDocumentClient.from(
  new DynamoDBClient({ region: "ca-central-1" })
);

export const handler = async (event) => {
  console.log("EVENT RECEIVED:", event);

  const { name, email, message } = JSON.parse(event.body);

  // 1️⃣ Save to DynamoDB
  await dynamo.send(
    new PutCommand({
      TableName: process.env.TABLE_NAME,
      Item: {
        messageId: Date.now().toString(),
        name,
        email,
        message,
        createdAt: new Date().toISOString()
      }
    })
  );

  // 2️⃣ Send email via SES
  await ses.send(
    new SendEmailCommand({
      Source: "akinlonudayo@gmail.com", // must be verified
      Destination: {
        ToAddresses: ["akinlonudayo@yahoo.com"]
      },
      Message: {
        Subject: {
          Data: "New Contact Form Submission"
        },
        Body: {
          Text: {
            Data: `Name: ${name}
Email: ${email}

Message:
${message}`
          }
        }
      }
    })
  );

  return {
    statusCode: 200,
    headers: {
      "Access-Control-Allow-Origin": "*"
    },
    body: JSON.stringify({ success: true })
  };
};
